#include "iostream"
#include "vector"
#include "omp.h"
#include "cstdint"
#include "iomanip"

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

int main() {
    system("lscpu > hw_info.txt");
    const uint64_t N = 13086000; 

    std::cout << "====================================================\n";
    std::cout << "  Amdahl Reality Gap Practicum\n";
    std::cout << "  Student ID: 240103086 | Workload N: " << N << "\n";
    std::cout << "====================================================\n\n";

    std::cout << "--- PHASE 2: Sequential Baseline ---\n";
    
    {
        uint32_t dummy_max = 0;
        for (uint64_t i = 1; i <= N; ++i) {
            uint32_t s = collatz_steps(i);
            if (s > dummy_max) dummy_max = s;
        }
    }

    double seq_times[2];
    uint32_t seq_max_steps = 0;
    uint64_t seq_checksum = 0;

    for (int run = 0; run < 2; ++run) {
        uint32_t max_s = 0;
        uint64_t sum_s = 0;
        
        double start = omp_get_wtime();
        for (uint64_t i = 1; i <= N; ++i) {
            uint32_t s = collatz_steps(i);
            if (s > max_s) max_s = s;
            sum_s = (sum_s + s) % 1000000007;
        }
        double end = omp_get_wtime();
        
        seq_times[run] = end - start;
        seq_max_steps = max_s;
        seq_checksum = sum_s;
    }

    double T_seq = (seq_times[0] + seq_times[1]) / 2.0;
    std::cout << "Sequential Time (T_seq): " << std::fixed << std::setprecision(6) << T_seq << " s\n";
    std::cout << "Checksum: " << seq_checksum << " | Max Steps: " << seq_max_steps << "\n\n";

    std::cout << "--- PHASE 3: Multi-Thread Scaling ---\n";
    int max_supported = omp_get_max_threads();
    std::cout << "Max available threads on server: " << max_supported << "\n";

    std::vector thread_counts = { 1, 2, 4, 8, 16 };

    for (int k : thread_counts) {
        double runs[3];
        for (int r = 0; r < 3; ++r) {
            double start = omp_get_wtime();
            omp_set_num_threads(k);

            uint32_t global_max = 0;
            uint64_t global_sum = 0;

            #pragma omp parallel reduction(max:global_max) reduction(+:global_sum)
            {
                #pragma omp for
                for (uint64_t i = 1; i <= N; ++i) {
                    uint32_t s = collatz_steps(i);
                    if (s > global_max) global_max = s;
                    global_sum += s;
                }
            }
            double end = omp_get_wtime();
            runs[r] = end - start;
        }

        double T_k = (runs[1] + runs[2]) / 2.0;
        double S_emp = T_seq / T_k;

        std::cout << "Threads k=" << std::setw(2) << k 
                  << " | Avg T_k: " << std::setprecision(6) << T_k << " s"
                  << " | Speedup S_emp(k): " << std::setprecision(3) << S_emp << "x\n";
    }
    std::cout << "\n";

    std::cout << "--- PHASE 4A: False Sharing Penalty ---\n";
    omp_set_num_threads(max_supported);

    std::vector naive_hits(max_supported, 0);
    double t_start = omp_get_wtime();
    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        #pragma omp for
        for (uint64_t i = 1; i <= N; ++i) {
            if (collatz_steps(i) > 100) {
                naive_hits[tid]++;
            }
        }
    }
    double t_naive = omp_get_wtime() - t_start;

    uint64_t total_hits = 0;
    t_start = omp_get_wtime();
    #pragma omp parallel for reduction(+:total_hits)
    for (uint64_t i = 1; i <= N; ++i) {
        if (collatz_steps(i) > 100) {
            total_hits++;
        }
    }
    double t_mitigated = omp_get_wtime() - t_start;

    std::cout << "Variant 1 (Naive False Sharing): " << t_naive << " s\n";
    std::cout << "Variant 2 (Reduction Fix):      " << t_mitigated << " s\n";
    std::cout << "Penalty Ratio:                   " << (t_naive / t_mitigated) << "x\n\n";

    std::cout << "--- PHASE 4B: Loop Scheduling ---\n";

    auto benchmark_sched = [&](const char* name, auto lambda) {
        double start = omp_get_wtime();
        lambda();
        std::cout << std::left << std::setw(25) << name << ": " 
                  << std::fixed << std::setprecision(6) << (omp_get_wtime() - start) << " s\n";
    };

    benchmark_sched("schedule(static)", [&]() {
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 1; i <= N; ++i) collatz_steps(i);
    });

    benchmark_sched("schedule(static, 1000)", [&]() {
        #pragma omp parallel for schedule(static, 1000)
        for (uint64_t i = 1; i <= N; ++i) collatz_steps(i);
    });

    benchmark_sched("schedule(dynamic, 100)", [&]() {
        #pragma omp parallel for schedule(dynamic, 100)
        for (uint64_t i = 1; i <= N; ++i) collatz_steps(i);
    });

    benchmark_sched("schedule(dynamic, 10000)", [&]() {
        #pragma omp parallel for schedule(dynamic, 10000)
        for (uint64_t i = 1; i <= N; ++i) collatz_steps(i);
    });

    benchmark_sched("schedule(guided)", [&]() {
        #pragma omp parallel for schedule(guided)
        for (uint64_t i = 1; i <= N; ++i) collatz_steps(i);
    });

    return 0;
}